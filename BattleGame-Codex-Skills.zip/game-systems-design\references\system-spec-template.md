# System Specification Template

## Goal

- Intended player experience:
- Problem being solved:
- Non-goals:
- Protected behavior:

## Rules

List rules in runtime evaluation order.

## Formula

```text
Result = expression
```

| Symbol | Type | Unit | Range | Meaning |
|---|---|---|---|---|

State clamping, rounding, order of operations, and zero/negative behavior.

## Worked example

Use concrete values and show intermediate results.

## Interaction matrix

| Actor / Target | A | B | C |
|---|---|---|---|
| A |  |  |  |
| B |  |  |  |
| C |  |  |  |

Mark natural outcomes, explicit modifiers, invalid combinations, and unresolved cells separately.

## Tuning knobs

| Parameter | Candidate | Safe range | Increase effect | Decrease effect |
|---|---:|---:|---|---|

## Edge cases and exploits

Include boundaries, stacking, progression transitions, simultaneous events, unavailable data, and degenerate strategies.

## Acceptance criteria

Each criterion must be observable and have an evidence source.

## Dependencies and migration

List affected data, code, UI, AI, saves, analytics, content, documentation, and tests.
