---
name: game-systems-design
description: Design or revise game systems as explicit, implementable rules with formulas, interaction matrices, progression structures, tuning knobs, edge cases, and acceptance criteria. Use for combat, units, abilities, counters, economy, crafting, rewards, progression, AI-facing rules, or any mechanic that needs rigorous systems-design reasoning across any game or engine.
---

# Game Systems Design

Turn a design goal into a precise system without inventing project constraints.

## Establish context

1. Read project instructions and discover current design documents, data, code, tests, and telemetry.
2. Separate facts from assumptions.
3. Identify the player experience, allowed scope, protected behavior, and success criteria.
4. If a missing decision would materially change the design, present 2-4 options with tradeoffs and recommend one.

Do not treat a temporary task constraint as a permanent design law.

## Design workflow

1. Define the system goal and non-goals.
2. Describe entities, state, inputs, outputs, and lifecycle.
3. Specify rules in evaluation order.
4. Write every important formula with named variables, units, ranges, bounds, and one worked example.
5. Create a complete interaction matrix when three or more entities or rules interact.
6. Distinguish visible strength from explicit bonuses, counters, exceptions, and hidden modifiers.
7. List tuning knobs with safe ranges and expected effects.
8. Cover failure modes, boundary cases, progression transitions, and exploit paths.
9. Define observable acceptance criteria and the evidence needed to validate them.
10. Identify affected systems and migration risks.

Read `references/system-spec-template.md` when drafting a specification.

## Design discipline

- Prefer data-driven rules over scattered magic numbers.
- Do not claim genre convention as project intent.
- Avoid mechanics outside the user's stated scope.
- A counter must change an otherwise losing or disadvantageous matchup; a natural win is not a counter.
- Added coverage, flexibility, range, area damage, mobility, reliability, or information is part of the power budget even when a headline stat is unchanged.
- Preserve uncertainty: label values as hypotheses, candidates, tested values, or locked values.
- Keep formulas separate from empirical battlefield or playtest value.

## Handoff

Before implementation, provide:

- concise rule summary;
- formulas and variable table;
- interaction matrix;
- tuning table;
- edge cases;
- acceptance criteria;
- test plan;
- open decisions.

Do not edit project files unless the user asks to implement or save the design.
