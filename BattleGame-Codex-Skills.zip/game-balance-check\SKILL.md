---
name: game-balance-check
description: Audit game balance across combat, economy, progression, rewards, loot, units, abilities, or mixed systems using formulas, configuration, simulations, playtests, and telemetry. Use after balance changes or when looking for dominant options, dead content, broken curves, unfair counters, economy loops, power spikes, or values that need evidence-backed adjustment.
---

# Game Balance Check

Perform a read-only audit unless the user separately authorizes changes.

## Establish the balance contract

1. Read project instructions and locate the relevant design intent, data, formulas, implementation, tests, and telemetry.
2. Record the sources used.
3. Identify the intended comparison basis: equal cost, equal population, equal time, equal opportunity, equal skill, encounter budget, or another project-defined basis.
4. Identify protected baselines and documented exceptions for this audit only.
5. State missing evidence and assumptions.

## Analyze

Choose the relevant checks from `references/audit-checklists.md`.

Always:

- reproduce project formulas exactly, including rounding and clamping;
- distinguish theoretical value from observed value;
- search for strict dominance and choices that are never rational;
- inspect both per-unit and system-level effects;
- check progression discontinuities and old-content relevance;
- verify that labels such as counter, tank, support, or elite match actual behavior;
- test sensitivity near breakpoints rather than recommending arbitrary percentages;
- consider AI selection and target access when AI participates in the system.

For stochastic or spatial systems, do not conclude from one run.

## Counter audit

A claimed counter requires evidence that:

1. the attacker is disadvantaged or loses without the counter modifier;
2. the modifier reverses the intended matchup;
3. the result is not an accidental consequence of pathing, targeting, formation, or unrelated stats;
4. the counter does not create unintended dominance elsewhere.

## Report

Return one verdict:

- `HEALTHY`
- `CONCERNS`
- `CRITICAL`

Include:

- sources and comparison basis;
- formula checks;
- outliers and dominant strategies;
- progression or economy curve findings;
- evidence gaps;
- prioritized recommendations;
- exact verification steps.

Mark each finding as `PROVEN`, `LIKELY`, or `NEEDS TESTING`. Do not silently edit values.
