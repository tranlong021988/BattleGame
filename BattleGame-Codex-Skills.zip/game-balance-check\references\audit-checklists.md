# Balance Audit Checklists

## Combat

- Damage per hit and DPS after mitigation
- Hits/time to kill at meaningful breakpoints
- Effective health, healing, regeneration, and sustain
- Range, mobility, cadence, accuracy, AoE, crowding, and target access
- Unit count, population, production time, cooldown, and opportunity cost
- Counter-off versus counter-on result
- Reverse matchup and mixed-composition behavior
- Strictly dominant or never-correct options

## Economy

- Resource sources, sinks, rates, caps, and conversion loops
- Time-to-afford and recovery after spending
- Infinite accumulation or depletion
- Price/value consistency and dead purchases
- Early advantage snowballing and comeback pressure
- Inflation across progression stages

## Progression

- Power and cost curves
- Dead zones and sudden spikes
- Unlock timing versus available challenges
- Whether old options retain a reason to exist
- Upgrade efficiency and skip/grind strategies
- Cross-tier or cross-level interaction coverage

## Rewards and loot

- Expected acquisition time and variance
- Floor, ceiling, pity, and duplicate behavior
- Inventory pressure and useless outcomes
- Reward value versus effort and risk

## Evidence quality

Prefer, in order:

1. deterministic formula or invariant;
2. isolated controlled test;
3. repeated simulation;
4. representative telemetry;
5. qualitative playtest observation;
6. genre intuition.

Do not present a lower-quality source as proof when a higher-quality check is available.
