---
name: game-design-consistency
description: Review a game project for contradictions, stale assumptions, missing downstream impacts, inconsistent terminology, duplicated sources of truth, and mismatches between design intent, data, implementation, UI, AI, tests, and telemetry. Use before implementing a major mechanic, after revising a design, or when multiple systems appear out of sync.
---

# Game Design Consistency

Perform a read-only cross-system review unless asked to propagate approved changes.

## Discover authority

1. Read project instructions.
2. Map candidate sources of truth for design, data, formulas, code, UI, AI, tests, analytics, and release notes.
3. Identify which source is authoritative for each fact.
4. Flag ambiguity instead of choosing a winner silently.

## Trace the change

Read `references/impact-map.md`.

For each requirement or proposed change:

1. State the intended behavior.
2. Trace every consumer and representation.
3. Compare names, units, defaults, bounds, formulas, and version assumptions.
4. Check save compatibility, migration, unlock state, AI behavior, UI explanation, analytics, and tests where applicable.
5. Identify stale documents and orphaned configuration.

## Review principles

- A duplicated value is a risk even when copies currently match.
- Documentation is not proof that runtime behavior matches.
- Implementation is not proof that the behavior matches design intent.
- A local change can alter economy, progression, AI, UI, difficulty, performance, or content pacing.
- Temporary task constraints must not become permanent rules without approval.
- Distinguish contradiction, omission, ambiguity, and deliberate exception.

## Report

Return one verdict:

- `CONSISTENT`
- `NEEDS UPDATE`
- `CONFLICTED`

For each issue include:

- authoritative source or unresolved authority;
- conflicting locations;
- player or production impact;
- recommended owner/action;
- verification step.

Do not propagate changes until the user confirms which source should win.
