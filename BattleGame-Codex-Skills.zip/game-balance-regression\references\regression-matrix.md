# Regression Matrix Template

## Scope

| Item | Before | Candidate | Allowed to change? | Expected result |
|---|---|---|---|---|

## Test cases

| ID | Layer | Scenario | Control variables | Metric | Pass range |
|---|---|---|---|---|---|
| R1 | Static |  |  |  |  |
| R2 | Isolated |  |  |  |  |
| R3 | Integration |  |  |  |  |
| R4 | Batch/playtest |  |  |  |  |

## Required controls

- One unchanged reference option
- Reverse interaction
- Boundary below the changed value
- Boundary above the changed value
- Mirrored side or equivalent symmetry check
- Multiple seeds when randomness exists

## Evidence

Record configuration, version or commit, seed, sample size, raw output path, summary metric, and observed anomalies.

## Interpretation

- Formula pass does not prove battlefield balance.
- Aggregate pass can hide a broken isolated matchup.
- A selection-frequency failure may be AI or affordability rather than combat power.
- A noisy result requires a larger sample or tighter controls, not immediate retuning.
