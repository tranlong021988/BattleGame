# Design Change Impact Map

## Authority map

| Fact or rule | Authoritative source | Mirrors/consumers | Owner | Status |
|---|---|---|---|---|

## Change propagation

Check only relevant domains:

- design specification;
- configuration and data;
- runtime formula and ordering;
- player-facing UI and terminology;
- AI evaluation and behavior;
- economy and progression;
- save/load and migration;
- content and encounters;
- tests and fixtures;
- telemetry and analytics;
- performance budgets;
- release notes and localization.

## Issue classes

| Class | Meaning |
|---|---|
| Contradiction | Two sources assert incompatible facts |
| Omission | A required consumer was not updated |
| Ambiguity | Authority or intended behavior is unclear |
| Stale mirror | A copied value no longer matches its source |
| Deliberate exception | Difference is documented and intentional |

## Resolution record

For each issue record the chosen authority, affected files or systems, migration requirement, test evidence, and approval status.
