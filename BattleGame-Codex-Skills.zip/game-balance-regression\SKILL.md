---
name: game-balance-regression
description: Verify that a game balance or mechanics change preserves intended behavior and produces the requested new behavior using before/after baselines, controlled tests, simulations, playtests, and telemetry. Use after changing stats, formulas, counters, progression, economies, AI tuning, rewards, or content values in any game or engine.
---

# Game Balance Regression

Build evidence from narrow deterministic checks to broad gameplay evidence.

## Establish the baseline

1. Read project instructions and discover existing tests, reports, telemetry, balance documents, data, and implementation.
2. Select a baseline appropriate to the task:
   - current committed state;
   - explicit snapshot;
   - previous release;
   - user-approved table or report.
3. Record which behavior may change and which must remain stable.
4. Do not encode temporary protected values into the reusable skill.

## Build the matrix

Read `references/regression-matrix.md`.

Include:

- changed cases;
- unchanged control cases;
- boundary and breakpoint cases;
- reverse interactions;
- same-level and cross-progression cases where relevant;
- mirrored sides or equivalent symmetry checks;
- multiple seeds for stochastic systems.

## Execute in stages

1. Static validation: schema, formulas, references, parity, and configuration.
2. Unit or isolated simulation.
3. Controlled matchup or scenario.
4. Mixed-system integration.
5. Full representative batches or playtests.
6. Performance and AI-behavior checks when relevant.

Stop broad testing when a required narrow invariant already fails.

## Diagnose before retuning

Separate:

- wrong data;
- wrong formula;
- stale configuration;
- targeting, pathing, formation, or access;
- AI evaluation and affordability;
- statistical noise;
- genuine balance failure.

Do not compensate for a behavior bug by changing balance values.

## Report

Return:

- `PASS`
- `PASS WITH CONCERNS`
- `FAIL`
- `BLOCKED`

Include baseline, changed scope, test matrix, results, variance, regressions, evidence files, and the smallest next action.
